
package com.mycompany.projeto27_vinicius;

import javax.swing.*;
import java.awt.*;

public class Projeto27_Vinicius extends JFrame {
        private JTextField campoFuncionario, campoEmail;
        private JPasswordField campoSenha;
        private JButton botaoCadastrar, botaoCancelar;

        public Projeto27_Vinicius() {
            // Configurações básicas da janela
            setTitle("Cadastro de Funcionário");
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setSize(300, 200);
            setLocationRelativeTo(null); // Centraliza a janela na tela

            // Criação dos campos de texto
            campoFuncionario = new JTextField(15);
            campoEmail = new JTextField(15);
            campoSenha = new JPasswordField(15);

            // Criação dos botões
            botaoCadastrar = new JButton("Cadastrar");
            botaoCancelar = new JButton("Cancelar");

            // Layout
            setLayout(new GridLayout(4, 2)); // GridLayout com 4 linhas e 2 colunas

            // Adicionando os componentes à janela
            add(new JLabel("Funcionário:"));
            add(campoFuncionario);
            add(new JLabel("E-mail:"));
            add(campoEmail);
            add(new JLabel("Senha:"));
            add(campoSenha);
            add(botaoCadastrar);
            add(botaoCancelar);

            // Exibir a janela
            setVisible(true);
        }

        public static void main(String[] args) {
            // Criando uma instância da classe MinhaTela
            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    new Projeto27_Vinicius();
                }
            });
        }
    }

